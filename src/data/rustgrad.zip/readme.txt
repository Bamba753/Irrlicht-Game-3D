November 19, 2014
================================================================
Title		: Rustgrad
Version		: Public Release
Filename	: rustgrad.bsp
Author		: Jochum Skoglund / Hipshot
www		: http://www.zfight.com
================================================================

* Play Information *

Designed for	: TDM FFA
Bots		: Yes
New Graphics	: Yes
New sounds	: Yes
Powerups	: Quad


* Credits *

Except for a few stock iD textures, the grass straw texture (Sock) and the box texture (quake retext project)
all other textures were made by me, please credit me if assets used elsewhere.

These are the specific textures not made by me, don't use these w/o proper permission:
grass_sprite
crate0_side
crate0_top
crate1_side
crate1_top

Most textures uses photosource from cgtextures.com.
Some of them are produced from my own photosource.

Sound are taken from freesound.org, search for the id's to find the source.